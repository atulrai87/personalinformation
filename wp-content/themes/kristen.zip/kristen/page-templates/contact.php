<?php
/* Template Name: Contact us  */
?>
<?php
get_header();
?>

<section class="full_width index_body">
<div class="main_container">
<div class="main_inner">
<div class="main_heading full_width">
  <h1 class="red_color ">Contact Me</h1>
  <div class="main_headingBorder"></div>
</div>
<div class="contact_part full_width top_margin">
<p>To contact the campaign team, please email </p>
<p><a href="">campaign@brownforcolumbus.com</a> </p>
<p class="top_margin">To donate, please donate online <a href="">here <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">

<input type="hidden" name="cmd" value="_s-xclick">

<input type="hidden" name="hosted_button_id" value="B5EW8MUC9GWBG">

<input type="image" src="http://www.brownforcolumbus.com/wp-content/themes/thesis_18/custom/images/btn-DONATE.png" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">

<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">

</form></a>  or make checks  payable to Friends of Kristen Brown, and mail to the following address:</p>
<div class="address_part full_width ">
<div class="address_content">
Friends of Kristen Brown
1332 11th Street
Columbus, IN 47201
</div>
<div class="blank_part"></div></div>
<p class="top_margin">To contact Kristen directly by email or phone:
</p>
<p><a href="">kristen@brownforcolumbus.com</a></p>
<p>812-447-2994</p>
<p>Thank you for your support!</p>
</div>	
</div>
  </div>
</section>

<?php
get_footer();
?>
